angular.module('popup', [])
  .service('Storage', ['$rootScope', function($rootScope) {
    return {
    };
 }]);
